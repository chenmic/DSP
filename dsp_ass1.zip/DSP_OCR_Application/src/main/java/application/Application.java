package application;

import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;

import javax.jms.JMSException;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
 
public class Application {
	
	private static String InputFile;
	private static Long Ratio;
	private static String QueueToManager = "QueueAppToManager";
	private static String Unique = ("" + UUID.randomUUID()).toLowerCase().replace("-", "");
	public static ReentrantLock Lock = new ReentrantLock();
	
    public static void main(String[] args){
    	
    	if (args.length<5){
    		System.err.println("Bad amount of arguments for Application.\n");
    		System.exit(1);
    	}
    	InputFile = args[3];
    	Ratio = Long.parseLong(args[4]);
    	
    	AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider().getCredentials());
        AmazonEC2 ec2 = AmazonEC2ClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        AmazonSQS sqs = AmazonSQSClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        
        String textFileBucket = "imagesfilebucket" + Unique;
        String queueFromManager = "QueueManagerToApp" + Unique;
        
        Bucket bucket = ApplicationS3Methods.createS3BucketIfNotExist(s3, textFileBucket);
        String msg = ApplicationS3Methods.uploadToS3Bucket(s3,textFileBucket,InputFile);
        msg = msg + " " + Ratio + " " + Unique; 											// msg = bucketName fileName Ratio Unique
        String queueUrl1 = ApplicationSQSMethods.createSQSIfNotExist(sqs,QueueToManager);
        ApplicationSQSMethods.sendOnSQS(sqs,QueueToManager,msg);
        String queueUrl2 = ApplicationSQSMethods.createSQSIfNotExist(sqs,queueFromManager);
        //Instance manager = ApplicationEC2Methods.createManagerIfNotExist(ec2);
       
        try {
        	ApplicationQueueListener listener = new ApplicationQueueListener();
        	ApplicationSQSConsumer consumer = new ApplicationSQSConsumer(credentialsProvider,queueFromManager,listener);
			consumer.start();
			synchronized (Lock) {
				if (listener.getResponse() == null)
					Lock.wait();
			}
			
		     // TODO
	        System.out.println("Recieved an html file from S3.");
				
			
			String[] result = listener.getResponse().split(" ");
			String bucketName2 = result[0];
			String fileName1 = result[1];
			
			S3Object summaryFile = ApplicationS3Methods.DownloadFromS3Bucket(s3,bucketName2,fileName1);
			 // TODO
	        System.out.println("file downloaded.");
            HTMLMethods.createHtmlFile(summaryFile);
			// Should the manager create the html file and then the app only saves it to drive?
			
			consumer.close();
			//ApplicationEC2Methods.terminateManager(ec2,manager);
	        ApplicationSQSMethods.deleteSQS(sqs, queueUrl1);
	        ApplicationSQSMethods.deleteSQS(sqs, queueUrl2);
	        ApplicationS3Methods.deleteS3Bucket(s3, bucket.getName());
	        ApplicationS3Methods.deleteS3Bucket(s3, bucketName2);
		} catch (JMSException e) {
			System.err.println("Failed to create or listen on " + queueFromManager + ".\n");
			e.printStackTrace();
			System.exit(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
              	
    }
      
}