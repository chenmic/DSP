package application;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class ApplicationQueueListener implements MessageListener {
	
	private String BucketFile = null;
 
    public void onMessage(Message message) {
    	
        try {
        	BucketFile =  ((TextMessage) message).getText();
        	synchronized (Application.Lock){
        		Application.Lock.notifyAll();
        	}
        	message.acknowledge();
        } catch (JMSException e) {
        	System.err.println("Failed to read receieved message.\n");
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    public String getResponse(){
    	return BucketFile;
    }
}