package application;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.List;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Filter;
import com.amazonaws.services.ec2.model.IamInstanceProfileSpecification;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceStateChange;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TagSpecification;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class ApplicationEC2Methods {
	
	private static String ManagerStartupScript = "#!/bin/bash\ncd home/ec2-user/\njava -jar manager.jar 1> out 2> err\n";
	
	public static Instance createManagerIfNotExist(AmazonEC2 ec2){
    	Instance manager = findManager(ec2);
    	if (manager == null){
    		try {
                RunInstancesRequest request = new RunInstancesRequest("ami-016e2ec5d009b9715", 1, 1);
                request.setInstanceType(InstanceType.T2Micro.toString());
                request.withTagSpecifications(new TagSpecification().withResourceType("instance")
        				.withTags(new Tag().withKey("Role").withValue("Manager")))
                		.withUserData(Base64.getEncoder().encodeToString(ManagerStartupScript.getBytes("UTF-8")))
                		.withKeyName("manager")
                		.withIamInstanceProfile(new IamInstanceProfileSpecification().withArn("arn:aws:iam::268899195186:instance-profile/Manager"));
                RunInstancesResult response = ec2.runInstances(request);
                List<Instance> instances = response.getReservation().getInstances();
                System.out.println("Launched instances: " + instances);
                
    			manager = response.getReservation().getInstances().get(0);		
            } catch (AmazonServiceException ase) {
                System.out.println("Caught Exception: " + ase.getMessage());
                System.out.println("Reponse Status Code: " + ase.getStatusCode());
                System.out.println("Error Code: " + ase.getErrorCode());
                System.out.println("Request ID: " + ase.getRequestId());
            } catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
    	}   	
    	return manager;
    }
    
    public static Instance findManager(AmazonEC2 ec2){
    	DescribeInstancesRequest request = new DescribeInstancesRequest();
    	Filter filter1 = new Filter("tag:Role").withValues("Manager");
    	Filter filter2 = new Filter("instance-state-name").withValues("pending", "running");
    	DescribeInstancesResult response = ec2.describeInstances(request.withFilters(filter1, filter2));
    	if (response.getReservations().size() == 0)
    		return null;
    	return response.getReservations().get(0).getInstances().get(0);

    }
    
    public static void terminateManager(AmazonEC2 ec2, Instance manager){
    	TerminateInstancesRequest request = new TerminateInstancesRequest().withInstanceIds(manager.getInstanceId());
		TerminateInstancesResult response = ec2.terminateInstances(request);
        List<InstanceStateChange> instances = response.getTerminatingInstances();
        System.out.println("Terminated instances: " + instances + ".\n");
    }
    
}