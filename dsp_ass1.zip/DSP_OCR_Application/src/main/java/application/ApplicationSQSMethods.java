package application;


import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteQueueRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;

public class ApplicationSQSMethods {
	
	public static String createSQSIfNotExist(AmazonSQS sqs, String queueName){
        for (String url : sqs.listQueues().getQueueUrls()){
        	String[] splitUrl = url.split("/");
        	if (splitUrl[splitUrl.length-1].equals(queueName))  
        		return url;
        }
		System.out.println("Creating queue " + queueName + ".\n");
        return sqs.createQueue(queueName).getQueueUrl();
    }
    
    public static void sendOnSQS(AmazonSQS sqs, String queueUrl, String msg){ 
    	System.out.println("Sending a message on queue.\n");
        sqs.sendMessage(new SendMessageRequest(queueUrl, msg));
    }
     
    public static void deleteSQS(AmazonSQS sqs, String queueUrl){ 
    	System.out.println("Deleting the queue.\n");
        sqs.deleteQueue(new DeleteQueueRequest(queueUrl));
    }

}
