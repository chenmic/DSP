package manager;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class WorkersToManagerQueueListener implements MessageListener {
	
	private List<ImageText> list = new ArrayList<ImageText>();
 
    public void onMessage(Message message) {
    	
    	System.out.println("Manager listener recieved message on queue.");
    	
        try {
        	String[] response = ((TextMessage) message).getText().split(" ",2);
        	list.add(new ImageText(response[0],response[1]));
        	synchronized (Manager.Lock2){
        		System.out.println("about to notify manager on lock2.");
        		Manager.Lock2.notifyAll();
        	}
        	message.acknowledge();
        } catch (JMSException e) {
        	System.err.println("Failed to read receieved message.\n");
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    public Long getSize(){
    	return new Long(list.size());
    }
    
    public ArrayList<ImageText> getList(){
    	return new ArrayList<ImageText>(list);
    }
}