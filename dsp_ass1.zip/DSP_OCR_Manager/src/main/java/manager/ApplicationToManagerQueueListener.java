package manager;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class ApplicationToManagerQueueListener implements MessageListener {
	 
    public void onMessage(Message message) {
    	
        try {
 
        	Manager.ThreadPoolForApplications.execute(new ManagerThread(((TextMessage) message).getText()));
        	message.acknowledge();
        } catch (JMSException e) {
        	System.err.println("Failed to read receieved message.\n");
            e.printStackTrace();
            System.exit(1);
        }
    }
    
}