package manager;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
//import java.util.Base64;
import org.apache.commons.codec.binary.Base64;
import java.util.List;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Filter;
import com.amazonaws.services.ec2.model.IamInstanceProfileSpecification;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceStateChange;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TagSpecification;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class ManagerEC2Methods {
	
	private static String WorkerStartupScript = "#!/bin/bash\ncd home/ec2-user/\njava -jar worker.jar ";
    
    public static Instance createWorker(AmazonEC2 ec2, String unique){
    	Instance worker = null;
    		try {
                RunInstancesRequest request = new RunInstancesRequest("ami-09163ae1a505e9b18", 1, 1);
                request.setInstanceType(InstanceType.T2Micro.toString());
                request.withTagSpecifications(new TagSpecification().withResourceType("instance")
        				.withTags(new Tag().withKey("Role").withValue("Worker")))
                		.withUserData(Base64.encodeBase64String(new String(WorkerStartupScript + unique + " 1> out 2> err\n").getBytes("UTF-8")))
                		.withKeyName("worker")
                		.withIamInstanceProfile(new IamInstanceProfileSpecification().withArn("arn:aws:iam::268899195186:instance-profile/Worker"));
                RunInstancesResult response = ec2.runInstances(request);
                List<Instance> instances = response.getReservation().getInstances();
                System.out.println("Launched instances: " + instances);
                
    			worker = response.getReservation().getInstances().get(0);		
            } catch (AmazonServiceException ase) {
                System.out.println("Caught Exception: " + ase.getMessage());
                System.out.println("Reponse Status Code: " + ase.getStatusCode());
                System.out.println("Error Code: " + ase.getErrorCode());
                System.out.println("Request ID: " + ase.getRequestId());
            } catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    			
    	return worker;
    }
    
    public static void terminateWorkers(AmazonEC2 ec2){
    	ArrayList<String> instanceIds= new ArrayList<String>();
    	DescribeInstancesRequest request = new DescribeInstancesRequest();
    	Filter filter = new Filter("tag:Role").withValues("Worker");
    	DescribeInstancesResult response = ec2.describeInstances(request.withFilters(filter));
    	if (response.getReservations().size() == 0)
    		return;
    	for (Reservation reservation : response.getReservations()){
    		for (Instance instance : reservation.getInstances()){
    			instanceIds.add(instance.getInstanceId());
    		}
    	}
		TerminateInstancesRequest terRequest = new TerminateInstancesRequest().withInstanceIds(instanceIds);
		TerminateInstancesResult terResponse = ec2.terminateInstances(terRequest);
		List<InstanceStateChange> instances = terResponse.getTerminatingInstances();
        System.out.println("Terminated instances: " + instances + ".\n");
    }
}
