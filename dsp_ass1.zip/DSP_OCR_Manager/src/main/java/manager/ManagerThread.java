package manager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

import javax.jms.JMSException;

import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.S3Object;

public class ManagerThread implements Runnable{
	
	private static String MsgFromApp;
	private static String Unique;
	
	
	public ManagerThread(String msgFromApp) {
		super();
		MsgFromApp = msgFromApp;
	}

	public void run() {
		Manager.Lock2 = new ReentrantLock();
		String[] result = MsgFromApp.split(" ");
		String textFileBucket = result[0];
		String inputFileNameFromApp = result[1];
		String ratio = result[2];
		Unique = result[3];
		
        String htmlFileBucket = "htmlfilebucket" + Unique;
        String queueToWorkers = "QueueManagerToWorkers" + Unique;
        String queueFromWorkers = "QueueWorkersToManager" + Unique;
        String QueueToApp = "QueueManagerToApp" + Unique;
		String queueToWorkersUrl = ManagerSQSMethods.createSQSIfNotExist(Manager.SQS,queueToWorkers);
		String queueFromWorkersUrl = ManagerSQSMethods.createSQSIfNotExist(Manager.SQS,queueFromWorkers);
		
		// Downloading and reading input file
		S3Object textFile = ManagerS3Methods.DownloadFromS3Bucket(Manager.S3,textFileBucket,inputFileNameFromApp);
		InputStream in = textFile.getObjectContent();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        Long count = new Long(0);
        String url = null;
        try {
        	// Creating workers based on ratio and sending tasks on the SQS.
			while ((url = reader.readLine()) != null) {
			    if (count.longValue() % Long.parseLong(ratio) == 0){
			    	//ManagerEC2Methods.createWorker(Manager.EC2,Unique);
			    	// TODO - tell the workers what to do
			    }
			    count = count.longValue()+1;
			    ManagerSQSMethods.sendOnSQS(Manager.SQS,queueToWorkers,url);
			}
			reader.close();
		} catch (NumberFormatException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
        
        // TODO
        System.out.println("Finished uploading to SQS");
        
        Bucket bucket = ManagerS3Methods.createS3BucketIfNotExist(Manager.S3, htmlFileBucket);
        
        WorkersToManagerQueueListener listener2 = new WorkersToManagerQueueListener();
        
        ManagerSQSConsumer consumer2 = null;
        try {
    		consumer2 = new ManagerSQSConsumer(Manager.CredentialsProvider,queueFromWorkers,listener2);
			consumer2.start();
		} catch (JMSException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
//        while(true){
//        	System.out.println("manager in while loop.");
//        	synchronized (Lock2) {
//        		if (!ManagerSQSMethods.isEmpty(sqs, queueName1))
//				try {
//					Lock2.wait();
//					System.out.println("manager recieved notification on lock2.");
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}	
//			else
//        		break;
//        	}
//        }
//        
//     // TODO
//        System.out.println("All workers finished.");
        
        // Manager will stay in while until all workers are done.
        while (true){
        	synchronized (Manager.Lock2) {
	        	if (!(listener2.getSize().longValue() == count.longValue()))
					try {				
						Manager.Lock2.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				else
	        		break;
        	}
        }
        
        // TODO
        System.out.println("Starting to build html file.");
        
        ArrayList<ImageText> list = listener2.getList();
		try {
	        File outputFile = new File("htmlFile.txt");
			FileOutputStream os;
				os = new FileOutputStream(outputFile);
	        OutputStreamWriter osw = new OutputStreamWriter(os);    
	        Writer w = new BufferedWriter(osw);
	        for (ImageText l : list){
	        	w.write(l.getUrl() + "\n" + l.getText() + "\n");
	        }
	        w.close();
	        
	        // Uploading the summary file and sending notification on SQS.
	        String msg = ManagerS3Methods.uploadToS3Bucket(Manager.S3,bucket.getName(),"htmlFile.txt");      // msg = bucketName fileName        
	        ManagerSQSMethods.sendOnSQS(Manager.SQS,QueueToApp,msg);
	        outputFile.delete();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
        
        try {
	        consumer2.close();
	      //ManagerEC2Methods.terminateWorkers(ec2);
	        ManagerSQSMethods.deleteSQS(Manager.SQS, queueToWorkersUrl);
	        ManagerSQSMethods.deleteSQS(Manager.SQS, queueFromWorkersUrl);
        	synchronized (Manager.Lock){
        		Manager.Lock.notifyAll();
        	}
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
