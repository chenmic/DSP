package manager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.locks.ReentrantLock;

import javax.jms.JMSException;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class Manager {
	
	private static String QueueFromApp = "QueueAppToManager";
	public static ApplicationToManagerQueueListener QueueFromAppListener;
	public static AWSCredentialsProvider CredentialsProvider;
	public static AmazonSQS SQS;
	public static AmazonS3 S3;
	public static AmazonEC2 EC2;
	public static ReentrantLock Lock = new ReentrantLock();
	public static ReentrantLock Lock2;
	public static ExecutorService ThreadPoolForApplications;
	
	public static void main(String[] args){
		
    	
		//AWSCredentialsProvider credentialsProvider = new InstanceProfileCredentialsProvider(false);
    	CredentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider().getCredentials());
        try {
            CredentialsProvider.getCredentials();
        } catch (Exception e) {
        	System.err.print("Failed to retrieve credentials.\n");
        	e.printStackTrace();
			System.exit(1);
        }
        
        EC2 = AmazonEC2ClientBuilder.standard()
                .withCredentials(CredentialsProvider)
                .withRegion("us-east-2")
                .build();
        S3 = AmazonS3ClientBuilder.standard()
                .withCredentials(CredentialsProvider)
                .withRegion("us-east-2")
                .build();
        SQS = AmazonSQSClientBuilder.standard()
                .withCredentials(CredentialsProvider)
                .withRegion("us-east-2")
                .build();
        
        QueueFromAppListener = new ApplicationToManagerQueueListener();
        ManagerSQSConsumer consumer1 = null;
		try {
			consumer1 = new ManagerSQSConsumer(CredentialsProvider,QueueFromApp, QueueFromAppListener);
			consumer1.start();
		} catch (JMSException e2) {
			System.out.println("Consumer1 error.");
			e2.printStackTrace();
		}
		ThreadPoolForApplications = Executors.newFixedThreadPool(5);
		
		while(true) {
			synchronized (Lock) {
				try {
					Lock.wait();
					if ((((ThreadPoolExecutor) ThreadPoolForApplications).getActiveCount() == 0))
						break;
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			}
		}
		
		try {
			consumer1.close();
			ThreadPoolForApplications.shutdown();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


	}
}
