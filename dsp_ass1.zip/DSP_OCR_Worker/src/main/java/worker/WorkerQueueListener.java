package worker;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class WorkerQueueListener implements MessageListener {
	
	private static String QueueToManager = "QueueWorkersToManager" + Worker.Unique;
 
    public void onMessage(Message message) {
    	
    	try {
    		String input = ((TextMessage) message).getText();
    		String output;
		
			URL url = new URL(input);
			InputStream is = url.openStream();
			OutputStream os = new FileOutputStream((output = input.replace('\\', '_').replace('/','_').replace(':', '_')));
	
			byte[] b = new byte[2048];
			int length;
	
			while ((length = is.read(b)) != -1) {
				os.write(b, 0, length);
			}
	
			is.close();
			os.close();			
			
			WorkerOCRScanner ocrScanner = new WorkerOCRScanner();
			ocrScanner.loadTrainingImages("/home/chenmic/Desktop/");
			String result = ocrScanner.process(output);
	        String text = input + " " + result;
    		WorkerSQSMethods.sendOnSQS(Worker.sqs,QueueToManager,text);
    		message.acknowledge(); // Delete message from SQS queue
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    		
    }
    
}