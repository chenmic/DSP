package worker;


import javax.jms.JMSException;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class Worker {
	
	public static String Unique;
	public static AmazonSQS sqs;

	public static void main(String[] args){
		
		if (args.length<4){
    		System.err.println("Bad amount of arguments for Application.\n");
    		System.exit(1);
    	}
    	Unique = args[3];
		
		//AWSCredentialsProvider credentialsProvider = new InstanceProfileCredentialsProvider(false);
    	AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider().getCredentials());
        try {
            credentialsProvider.getCredentials();
        } catch (Exception e) {
        	System.err.print("Failed to retrieve credentials.\n");
        	e.printStackTrace();
			System.exit(1);
        }
        
        sqs = AmazonSQSClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        
        String QueueFromManager = "QueueManagerToWorkers" + Unique;
        WorkerQueueListener listener = new WorkerQueueListener();
        WorkerSQSConsumer consumer = null;
		try {
			consumer = new WorkerSQSConsumer(credentialsProvider,QueueFromManager, listener);
			consumer.start();
			// Worker will go to sleep and the listener will handle all incoming messages.
		    Object obj = new Object();
	    	synchronized (obj) {
	    		obj.wait();
	    	}
		} catch (JMSException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
