package worker;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class WorkerQueueListener implements MessageListener {
	
	private static String QueueToManager = "QueueWorkersToManager" + Worker.Unique;
 
    public void onMessage(Message message) {
    	
    	String text = "";
    	InputStream is = null;
    	OutputStream os = null;
    	try {
    		String input = ((TextMessage) message).getText();
    		text = input + " ";
    		String output;
		
			URL url = new URL(input);
			is = url.openStream();
			os = new FileOutputStream((output = input.replace('\\', '_').replace('/','_').replace(':', '_')));
	
			byte[] b = new byte[2048];
			int length;
	
			while ((length = is.read(b)) != -1) {
				os.write(b, 0, length);
			}		
			
			os.flush();
			String result = Worker.OCRScanner.process(output);
	        text += result;
   		} catch (IOException e) {
			text += "Failed to perform OCR.";
		} catch (JMSException e) {
			System.err.println("Failed reading message from queue " + QueueToManager + ".");
			e.printStackTrace();
		} finally {
			WorkerSQSMethods.sendOnSQS(Worker.SQS,QueueToManager,text);
			try {
		        message.acknowledge(); // Delete message from SQS queue even if OCR failed.
				if (is != null)
					is.close();
				if (os != null)
					os.close();
			} catch (IOException e) {
				System.err.println("Failed closing streams on message from queue " + QueueToManager + ".");
				e.printStackTrace();
			} catch (JMSException e) {
				System.err.println("Failed discarding message from queue " + QueueToManager + ".");
			}
			
		}
				
    }
    
}