package worker;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import javax.imageio.ImageIO;
import net.sourceforge.javaocr.ocrPlugins.mseOCR.CharacterRange;
import net.sourceforge.javaocr.ocrPlugins.mseOCR.OCRScanner;
import net.sourceforge.javaocr.ocrPlugins.mseOCR.TrainingImage;
import net.sourceforge.javaocr.ocrPlugins.mseOCR.TrainingImageLoader;
import net.sourceforge.javaocr.scanner.PixelImage;


public class WorkerOCRScanner{

    private Image image;
    private OCRScanner scanner;

    public WorkerOCRScanner(){
        scanner = new OCRScanner();
    }

    public void loadTrainingImages(String trainingImageDir){
        if (!trainingImageDir.endsWith(File.separator))
            trainingImageDir += File.separator;
        try{
            scanner.clearTrainingImages();
            TrainingImageLoader loader = new TrainingImageLoader();
            HashMap<Character, ArrayList<TrainingImage>> trainingImageMap = new HashMap<Character, ArrayList<TrainingImage>>();
            loader.load(
                    trainingImageDir + "ascii.png",
                    new CharacterRange('!', '~'),
                    trainingImageMap);
            loader.load(
                    trainingImageDir + "hpljPica.jpg",
                    new CharacterRange('!', '~'),
                    trainingImageMap);
            loader.load(
                    trainingImageDir + "digits.jpg",
                    new CharacterRange('0', '9'),
                    trainingImageMap);
            scanner.addTrainingImages(trainingImageMap);
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
    }

    public String process(String imageFilename){
    	String result = "";
        try{
            image = ImageIO.read(new File(imageFilename));
            if (image != null) {
		        PixelImage pixelImage = new PixelImage(image);
		        pixelImage.toGrayScale(true);
		        pixelImage.filter();
		        result = scanner.scan(image, 0, 0, 0, 0, null);
		        image.flush();
            }
        }
        catch (IOException e){
			System.err.println(e.getMessage());
        } finally {
        	image = null;
        }
        if (!result.equals(""))
        	return result.replace("\n", "<br/>");
        else
        	return "Failed_to_process_image";
        
    }
}