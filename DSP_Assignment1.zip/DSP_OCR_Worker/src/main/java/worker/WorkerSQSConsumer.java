package worker;

import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.Session;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnection;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class WorkerSQSConsumer {
	
	private SQSConnectionFactory connectionFactory;
	private SQSConnection connection;
	private Session session;
	private Queue queue;
	private MessageConsumer consumer;
	
	public WorkerSQSConsumer(AWSCredentialsProvider credentialsProvider, String queueName, MessageListener listener) throws JMSException{

		connectionFactory = new SQSConnectionFactory
    		(new ProviderConfiguration(),AmazonSQSClientBuilder.standard()
            .withCredentials(credentialsProvider)
            .withRegion("us-east-2"));
    
		connection = connectionFactory.createConnection();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		queue = session.createQueue(queueName);
		consumer = session.createConsumer(queue);
		consumer.setMessageListener(listener);
	}
	
	public void start() throws JMSException{
		connection.start();
	}
	
	public void close() throws JMSException{
		connection.close();
	}

}