package worker;


import javax.jms.JMSException;

import com.amazonaws.auth.AWSCredentialsProvider;
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
//import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class Worker {
	
	public static String Unique;
	public static AmazonSQS SQS;
	public static WorkerOCRScanner OCRScanner;

	public static void main(String[] args){
		
		if (args.length<1){
    		System.err.println("Bad amount of arguments for Worker.");
    		System.exit(1);
    	}
    	Unique = args[0];
		
		AWSCredentialsProvider credentialsProvider = new InstanceProfileCredentialsProvider(false);
    	//AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider().getCredentials());
        try {
            credentialsProvider.getCredentials();
        } catch (Exception e) {
        	System.err.println("Failed to retrieve credentials.");
        	e.printStackTrace();
			System.exit(1);
        }
        
        SQS = AmazonSQSClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        
        OCRScanner = new WorkerOCRScanner();
        OCRScanner.loadTrainingImages("/home/ec2-user/ocrtraining/");
        
        String QueueFromManager = "QueueManagerToWorkers" + Unique;
        WorkerQueueListener listener = new WorkerQueueListener();
        WorkerSQSConsumer consumer = null;
		try {
			consumer = new WorkerSQSConsumer(credentialsProvider,QueueFromManager, listener);
			consumer.start();
			// Worker will go to sleep and the listener will handle all incoming messages.
		    Object obj = new Object();
	    	synchronized (obj) {
	    		obj.wait();
	    	}
		} catch (JMSException e1) {
			System.err.println("Failed listening on queue: " + QueueFromManager + ".");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
