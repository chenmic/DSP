package application;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class ApplicationQueueListener implements MessageListener {
	
	private String response = null;
 
    public void onMessage(Message message) {
    	
        try {
        	response =  ((TextMessage) message).getText();
        	message.acknowledge();
        } catch (JMSException e) {
        	System.err.println("Failed reading receieved message from QueueManagerToApp.");
            e.printStackTrace();
        } finally {
        	synchronized (Application.Lock){
        		Application.Lock.notifyAll();
        	}
        }
    }
    
    public String getResponse(){
    	return response;
    }
}