package application;


import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteQueueRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;

public class ApplicationSQSMethods {
	
	public static String createSQSIfNotExist(AmazonSQS sqs, String queueName){
        for (String url : sqs.listQueues().getQueueUrls()){
        	String[] splitUrl = url.split("/");
        	if (splitUrl[splitUrl.length-1].equals(queueName))  
        		return url;
        }
        System.out.println("Creating queue " + queueName + ".");
        return sqs.createQueue(queueName).getQueueUrl();
    }
    
    public static void sendOnSQS(AmazonSQS sqs, String queueUrl, String msg){ 
    	System.out.println("Sending a message on queue " + queueUrl + ".");
        sqs.sendMessage(new SendMessageRequest(queueUrl, msg));
    }
     
    public static void deleteSQS(AmazonSQS sqs, String queueUrl){
    	String[] queueSplit = queueUrl.split("/");
    	System.out.println("Deleting the queue " + queueSplit[queueSplit.length-1] + ".");
        sqs.deleteQueue(new DeleteQueueRequest(queueUrl));
    }

}
