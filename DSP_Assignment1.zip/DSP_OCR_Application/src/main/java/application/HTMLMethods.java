package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import com.amazonaws.services.s3.model.S3Object;

public class HTMLMethods {
	
	private static String HTMLPageBegin = "<html>\n<title>OCR</title>\n<body>\n";
	private static String HTMLPageEnd = "</body>\n<html>";
	
	public static String createHTMLParagraph(String url, String text){
		return "\t<p>\n\t\t<img src=" + url + "><br/>\n\t\t" + text + "\n\t</p>\n";
	}
	
	public static void createHtmlFile(S3Object summaryFile, String Unique){
		
		BufferedWriter w = null;
		BufferedReader reader = null;
		try {
			File htmlFile = new File("output" + Unique + ".html");
			FileOutputStream os = new FileOutputStream(htmlFile);
	        OutputStreamWriter osw = new OutputStreamWriter(os);    
	        w = new BufferedWriter(osw);
			InputStream is = summaryFile.getObjectContent();
			reader = new BufferedReader(new InputStreamReader(is));
			String htmlText = HTMLPageBegin;
	        String line = reader.readLine();
			while (line != null && !line.equals("")) {
			    htmlText += createHTMLParagraph(line, reader.readLine());
			    line = reader.readLine();
			}
			htmlText += HTMLPageEnd;
			w.write(htmlText);
			w.flush();
		} catch (IOException e1) {
			System.err.println("Failed to create html file.");
		} finally {
			try {
				summaryFile.close();
				if (reader != null)
					reader.close();
				if (w != null)
					w.close();
			} catch (IOException e) {
				System.err.println("Failed closing " + summaryFile.getKey() + " stream from bucket " + summaryFile.getBucketName() + ".");
			}
		}
		
	}
}
