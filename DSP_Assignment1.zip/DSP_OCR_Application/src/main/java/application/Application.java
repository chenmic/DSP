package application;

import java.util.UUID;

import javax.jms.JMSException;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
 
public class Application {
	
	private static String InputFile;
	private static Long Ratio;
	private static String Unique;
	private static String QueueToManager = "QueueAppToManager";
	public static Object Lock = new Object();
	private static String terminate = "false";
	
    public static void main(String[] args){
    	
    	if (args.length<2){
    		System.out.println("arg0 = " + args[0] + ", arg1 = " + args[1]);
    		System.err.println("Bad amount of arguments for Application.");
    		System.exit(1);
    	}
    	InputFile = args[0];
    	Ratio = Long.parseLong(args[1]);
    	if (args.length>2) {
    		if (args[2].toLowerCase().equals("true"))
    			terminate = "true";
    	}
    	Unique = ("" + UUID.randomUUID()).toLowerCase().replace("-", "");
    	
    	AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider().getCredentials());
        AmazonEC2 ec2 = AmazonEC2ClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        AmazonSQS sqs = AmazonSQSClientBuilder.standard()
                .withCredentials(credentialsProvider)
                .withRegion("us-east-2")
                .build();
        
        String textFileBucket = "imagesfilebucket" + Unique;
        String queueFromManager = "QueueManagerToApp" + Unique;
        
        Bucket bucket = ApplicationS3Methods.createS3BucketIfNotExist(s3, textFileBucket);
        String msg = ApplicationS3Methods.uploadToS3Bucket(s3,textFileBucket,InputFile);
        msg = terminate + " " + msg + " " + Ratio + " " + Unique;					// msg = bool bucketName fileName Ratio Unique
        ApplicationSQSMethods.createSQSIfNotExist(sqs,QueueToManager);
        ApplicationSQSMethods.sendOnSQS(sqs,QueueToManager,msg);
        String queueFromManagerURL = ApplicationSQSMethods.createSQSIfNotExist(sqs,queueFromManager);
        ApplicationEC2Methods.createManagerIfNotExist(ec2); // creating the manager.
       
        String bucketName2 = "";
        try {
        	ApplicationQueueListener listener = new ApplicationQueueListener();
        	ApplicationSQSConsumer consumer = new ApplicationSQSConsumer(credentialsProvider,queueFromManager,listener);
			consumer.start();
			
			// Application will sleep until it receives a summary file from the manager.
			synchronized (Lock) {
				if (listener.getResponse() == null) {
					System.out.println("Awaiting Manager's response...");
					Lock.wait();
				}
			}
			
			String[] result = listener.getResponse().split(" ");
			bucketName2 = result[0];
			String fileName1 = result[1];
			
	        System.out.println("Recieved a summary file to S3 bucket " + bucketName2 + ".");
			S3Object summaryFile = ApplicationS3Methods.DownloadFromS3Bucket(s3,bucketName2,fileName1);
            HTMLMethods.createHtmlFile(summaryFile, Unique);
			
			consumer.close();
		} catch (JMSException e) {
			System.err.println("Failed listening on " + queueFromManager + ".");
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			ApplicationSQSMethods.deleteSQS(sqs, queueFromManagerURL);
	        ApplicationS3Methods.deleteS3Bucket(s3, bucket.getName());
	        if (!bucketName2.equals(""))
	        	ApplicationS3Methods.deleteS3Bucket(s3, bucketName2);
	        System.out.println("Application finished.\nHTML file saved, Good Bye :)");
		}
              	
    }
      
}