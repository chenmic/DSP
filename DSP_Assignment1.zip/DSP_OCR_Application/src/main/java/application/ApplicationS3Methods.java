package application;

import java.io.File;
import java.util.Iterator;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class ApplicationS3Methods {
	
	public static Bucket createS3BucketIfNotExist(AmazonS3 s3, String bucketName){ 
        for (Bucket bucket : s3.listBuckets()) 
        	if (bucket.getName().equals(bucketName))
        		return bucket;	
        System.out.println("Creating bucket " + bucketName + ".");
        return s3.createBucket(bucketName);
    }
    
    public static String uploadToS3Bucket(AmazonS3 s3, String bucketName, String fileName){ 
    	System.out.println("Uploading " + fileName + " to s3 bucket " + bucketName + ".");
        File file = new File(fileName);
        String key = file.getName().replace('\\', '-').replace('/','-').replace(':', '-');
        PutObjectRequest req = new PutObjectRequest(bucketName, key, file);
        s3.putObject(req);
        return bucketName + " " + key;
    }
    
    public static S3Object DownloadFromS3Bucket(AmazonS3 s3, String bucketName, String fileName){ 
    	System.out.println("Downloading " + fileName + " from s3 bucket " + bucketName + ".");
        S3Object object = s3.getObject(new GetObjectRequest(bucketName, fileName.replace('\\', '-').replace('/','-').replace(':', '-')));
        return object;
    }
    
    public static void deleteS3Bucket(AmazonS3 s3, String bucketName){ 
    	System.out.println("Deleting bucket " + bucketName + ".");
    	ObjectListing objectListing = s3.listObjects(bucketName);
        while (true) {
            Iterator<S3ObjectSummary> bucketIter = objectListing.getObjectSummaries().iterator();
            while (bucketIter.hasNext()) {
                s3.deleteObject(bucketName, bucketIter.next().getKey());
            }

            // If the bucket contains many objects, the listObjects() call
            // might not return all of the objects in the first listing. Check to
            // see whether the listing was truncated. If so, retrieve the next page of objects 
            // and delete them.
            if (objectListing.isTruncated()) {
                objectListing = s3.listNextBatchOfObjects(objectListing);
            } else {
                break;
            }
        }
        s3.deleteBucket(bucketName);
    }
    
}
