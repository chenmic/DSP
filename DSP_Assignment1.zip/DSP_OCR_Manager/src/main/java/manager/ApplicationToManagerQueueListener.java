package manager;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class ApplicationToManagerQueueListener implements MessageListener {
	 
    public void onMessage(Message message) {
    	
        try {
        	String[] text = ((TextMessage) message).getText().split(" ",2);
        	Manager.ThreadPoolForApplications.execute(new ManagerThread(text[1]));
        	message.acknowledge();
        	// Received termination request.
        	if (text[0].equals("true")) {
        		synchronized(Manager.ManagerLock) {
        			Manager.ManagerLock.notifyAll();
        		}
        	}
        } catch (JMSException e) {
        	System.err.println("Failed reading message from queue QueueAppToManager.");
            e.printStackTrace();
        }
    }
    
}