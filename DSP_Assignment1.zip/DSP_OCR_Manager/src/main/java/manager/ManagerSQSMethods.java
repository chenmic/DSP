package manager;

import java.util.List;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteQueueRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;

public class ManagerSQSMethods {
	
	public static String createSQSIfNotExist(AmazonSQS sqs, String queueName){
        for (String url : sqs.listQueues().getQueueUrls()){
        	String[] splitUrl = url.split("/");
        	if (splitUrl[splitUrl.length-1].equals(queueName))  
        		return url;
        }
		System.out.println("Creating queue " + queueName + ".");
        return sqs.createQueue(queueName).getQueueUrl();
    }
    
    public static void sendOnSQS(AmazonSQS sqs, String queueUrl, String msg){ 
    	System.out.println("Sending a message on queue " + queueUrl + ".");
        sqs.sendMessage(new SendMessageRequest(queueUrl, msg));
    }
     
    public static void deleteSQS(AmazonSQS sqs, String queueUrl){ 
    	System.out.println("Deleting the queue " + queueUrl + ".");
        sqs.deleteQueue(new DeleteQueueRequest(queueUrl));
    }
    
    public static boolean isEmpty(AmazonSQS sqs, String queueUrl){ 
    	ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(queueUrl).withVisibilityTimeout(0);
    	List<Message> messages = sqs.receiveMessage(receiveMessageRequest).getMessages();
    	if (messages.size() == 0)
    		return true;
        return false;
    }

}
