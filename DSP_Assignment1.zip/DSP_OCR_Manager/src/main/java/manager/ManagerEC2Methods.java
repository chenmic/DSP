package manager;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
//import java.util.Base64;
import org.apache.commons.codec.binary.Base64;
import java.util.List;

import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Filter;
import com.amazonaws.services.ec2.model.IamInstanceProfileSpecification;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceStateChange;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TagSpecification;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class ManagerEC2Methods {
	
	private static String WorkerStartupScript = "#!/bin/bash\ncd home/ec2-user/\njava -jar worker.jar ";
    
    public static String createWorker(AmazonEC2 ec2, String unique){
    	Instance worker = null;
    		try {
                RunInstancesRequest request = new RunInstancesRequest("ami-0fbe0f4b3bedb7e84", 1, 1);
                request.setInstanceType(InstanceType.T2Micro.toString());
                request.withTagSpecifications(new TagSpecification().withResourceType("instance")
        				.withTags(new Tag().withKey("Role").withValue("Worker"), new Tag().withKey("ID").withValue(unique)))
                		.withUserData(Base64.encodeBase64String(new String(WorkerStartupScript + unique + " 1> out 2> err\n").getBytes("UTF-8")))
                		.withKeyName("worker")
                		.withIamInstanceProfile(new IamInstanceProfileSpecification().withArn("arn:aws:iam::268899195186:instance-profile/Worker"));
                RunInstancesResult response = ec2.runInstances(request);
                List<Instance> instances = response.getReservation().getInstances();
                System.out.println("Launched instances: " + instances);
    			worker = response.getReservation().getInstances().get(0);		
            } catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
    	if (worker != null)
    		return worker.getInstanceId();
    	else
    		return "";
    }
    
    public static void terminateWorkers(AmazonEC2 ec2, String unique){
    	ArrayList<String> instanceIds= new ArrayList<String>();
    	DescribeInstancesRequest request = new DescribeInstancesRequest();
    	Filter filter1 = new Filter("tag:Role").withValues("Worker");
    	Filter filter2 = new Filter("tag:ID").withValues(unique);
    	DescribeInstancesResult response = ec2.describeInstances(request.withFilters(filter1, filter2));
    	if (response.getReservations().size() == 0)
    		return;
    	for (Reservation reservation : response.getReservations()){
    		for (Instance instance : reservation.getInstances()){
    			instanceIds.add(instance.getInstanceId());
    		}
    	}
		TerminateInstancesRequest terRequest = new TerminateInstancesRequest().withInstanceIds(instanceIds);
		TerminateInstancesResult terResponse = ec2.terminateInstances(terRequest);
		List<InstanceStateChange> instances = terResponse.getTerminatingInstances();
        System.out.println("Terminated instances: " + instances + ".");
    }
    
    // Enables the manager to kill itself when it receives a termination message.
    public static void findAndKillManager(AmazonEC2 ec2) {
    	DescribeInstancesRequest request = new DescribeInstancesRequest();
    	Filter filter1 = new Filter("tag:Role").withValues("Manager");
    	Filter filter2 = new Filter("instance-state-name").withValues("pending", "running");
    	DescribeInstancesResult response = ec2.describeInstances(request.withFilters(filter1, filter2));
    	if (!(response.getReservations().size() == 0)) {
    		System.out.println("Manager is comitting suicide.");
    		Instance manager = response.getReservations().get(0).getInstances().get(0);
    		ec2.terminateInstances(new TerminateInstancesRequest().withInstanceIds(manager.getInstanceId()));
    	}

    }
    
}
