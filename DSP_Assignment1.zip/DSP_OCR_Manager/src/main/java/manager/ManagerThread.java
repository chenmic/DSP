package manager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;

import javax.jms.JMSException;

import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.S3Object;

public class ManagerThread implements Runnable{
	
	private static String MsgFromApp;
	public final Object ThreadLock = new Object();
	
	public ManagerThread(String msgFromApp) {
		super();
		MsgFromApp = msgFromApp;
	}

	public void run() {
		String[] result = MsgFromApp.split(" ");
		String textFileBucket = result[0];
		String inputFileNameFromApp = result[1];
		String ratio = result[2];
		String unique = result[3];
		
        String htmlFileBucket = "htmlfilebucket" + unique;
        String queueToWorkers = "QueueManagerToWorkers" + unique;
        String queueFromWorkers = "QueueWorkersToManager" + unique;
        String QueueToApp = "QueueManagerToApp" + unique;
		String queueToWorkersUrl = ManagerSQSMethods.createSQSIfNotExist(Manager.SQS,queueToWorkers);
		String queueFromWorkersUrl = ManagerSQSMethods.createSQSIfNotExist(Manager.SQS,queueFromWorkers);
		
		// Downloading and reading input file
		S3Object textFile = ManagerS3Methods.DownloadFromS3Bucket(Manager.S3,textFileBucket,inputFileNameFromApp);
		InputStream in = textFile.getObjectContent();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        Long count = new Long(0);
        String url = null;
        try {
        	// Creating workers based on ratio and sending tasks on the SQS.
			while ((url = reader.readLine()) != null) {
			    if (count.longValue() % Long.parseLong(ratio) == 0){
			    	ManagerEC2Methods.createWorker(Manager.EC2, unique);
			    }
			    count = count.longValue()+1;
			    ManagerSQSMethods.sendOnSQS(Manager.SQS,queueToWorkers,url);
			}
		} catch (NumberFormatException e2) {
			e2.printStackTrace();
		} catch (IOException e1) {
			System.err.println("Failed reading from input text file.");
			e1.printStackTrace();
		} finally {
			try {
				reader.close();
				textFile.close();
			} catch (IOException e) {
				System.err.println("Failed closing " + textFile.getKey() + " stream from bucket " + textFile.getBucketName() + ".");
				e.printStackTrace();
			}
		}
        
        System.out.println("Finished uploading to SQS.");
        Bucket bucket = ManagerS3Methods.createS3BucketIfNotExist(Manager.S3, htmlFileBucket);
        WorkersToManagerQueueListener listener2 = new WorkersToManagerQueueListener(ThreadLock);
        ManagerSQSConsumer consumer2 = null;
        try {
    		consumer2 = new ManagerSQSConsumer(Manager.CredentialsProvider,queueFromWorkers,listener2);
			consumer2.start();
		} catch (JMSException e) {
			System.err.println("Failed listening on queue: " + queueFromWorkers + ".");
			e.printStackTrace();
		}
        
        // Manager will stay in while loop until all workers are done.
        while(true){
        	synchronized (ThreadLock) {
        		if (!ManagerSQSMethods.isEmpty(Manager.SQS, queueToWorkers))
					try {
						System.out.println(queueToWorkers + " is not empty, going to sleep.");
						ThreadLock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}	
				else if (!(listener2.getSize().longValue() == count.longValue())) {
					try {
						System.out.println("Workers haven't processed all messages on " + queueFromWorkers + ", going to sleep.");
						ThreadLock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} else
					break;
	        }
        }
        
        System.out.println("All workers finished, starting to build summary file.");
        ArrayList<ImageText> list = listener2.getList();
        Writer w = null;
		try {
	        File outputFile = new File("summaryFile.txt");
			FileOutputStream os = new FileOutputStream(outputFile);
	        OutputStreamWriter osw = new OutputStreamWriter(os);    
	        w = new BufferedWriter(osw);
	        for (ImageText l : list){
	        	w.write(l.getUrl() + "\n" + l.getText() + "\n");
	        }
	        // Uploading the summary file and sending notification on SQS.
	        w.flush();
	        String msg = ManagerS3Methods.uploadToS3Bucket(Manager.S3,bucket.getName(),outputFile.getName());      // msg = bucketName fileName        
	        ManagerSQSMethods.sendOnSQS(Manager.SQS,QueueToApp,msg);
	        outputFile.delete();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			System.err.println("Failed to create summary file.");
		} finally {
				try {
					if (w != null)
						w.close();
				} catch (IOException e) {
					System.err.println("Failed to close summary file stream.");
				}
		}
		
		// Closing consumer and deleting workers and queues.
        try {
        	if (consumer2 != null)
        		consumer2.close();
        } catch (JMSException e) {
			System.err.println("Failed to close consumer for listener " + queueFromWorkers + ".");
			e.printStackTrace();
		}
	        ManagerEC2Methods.terminateWorkers(Manager.EC2, unique);
	        ManagerSQSMethods.deleteSQS(Manager.SQS, queueToWorkersUrl);
	        ManagerSQSMethods.deleteSQS(Manager.SQS, queueFromWorkersUrl);
        	synchronized (ThreadLock){
        		ThreadLock.notifyAll();
        	}
		
	}

}
