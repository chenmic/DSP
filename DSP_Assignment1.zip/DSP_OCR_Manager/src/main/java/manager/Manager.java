package manager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.jms.JMSException;

import com.amazonaws.auth.AWSCredentialsProvider;
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
//import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class Manager {
	
	private static String QueueFromApp = "QueueAppToManager";
	public static ApplicationToManagerQueueListener QueueFromAppListener;
	public static AWSCredentialsProvider CredentialsProvider;
	public static AmazonSQS SQS;
	public static AmazonS3 S3;
	public static AmazonEC2 EC2;
	public static ExecutorService ThreadPoolForApplications = Executors.newFixedThreadPool(5);
	public static Object ManagerLock = new Object();
	
	public static void main(String[] args){
		
    	
		CredentialsProvider = new InstanceProfileCredentialsProvider(false);
    	//CredentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider().getCredentials());
        try {
            CredentialsProvider.getCredentials();
        } catch (Exception e) {
        	System.err.println("Failed to retrieve credentials.");
        	e.printStackTrace();
			System.exit(1);
        }
        
        EC2 = AmazonEC2ClientBuilder.standard()
                .withCredentials(CredentialsProvider)
                .withRegion("us-east-2")
                .build();
        S3 = AmazonS3ClientBuilder.standard()
                .withCredentials(CredentialsProvider)
                .withRegion("us-east-2")
                .build();
        SQS = AmazonSQSClientBuilder.standard()
                .withCredentials(CredentialsProvider)
                .withRegion("us-east-2")
                .build();
        
        QueueFromAppListener = new ApplicationToManagerQueueListener();
        ManagerSQSConsumer consumer = null;
		try {
			consumer = new ManagerSQSConsumer(CredentialsProvider,QueueFromApp, QueueFromAppListener);
			consumer.start();
		} catch (JMSException e2) {
			System.err.println("Failed listening on queue: " + QueueFromApp + ".");
			e2.printStackTrace();
		}
		
		//Manager will sleep here until it will receive a termination message.
		synchronized (ManagerLock) {
			try {
				ManagerLock.wait();
				consumer.close();
				ThreadPoolForApplications.shutdown();
				ThreadPoolForApplications.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
				ManagerSQSMethods.deleteSQS(SQS, SQS.getQueueUrl(QueueFromApp).getQueueUrl());
				ManagerEC2Methods.findAndKillManager(EC2);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			} catch (JMSException e) {
				System.err.println("Failed to close consumer for listener " + QueueFromAppListener + ".");
			}
		}
		
	}
}
