package manager;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class WorkersToManagerQueueListener implements MessageListener {
	
	private List<ImageText> list = new ArrayList<ImageText>();
	private final Object ThreadLock;
	
	public WorkersToManagerQueueListener(Object ThreadLock) {
		this.ThreadLock = ThreadLock;
	}
 
    public void onMessage(Message message) {
    	
        try {
        	String[] response = ((TextMessage) message).getText().split(" ",2);
        	synchronized (ThreadLock){
        		list.add(new ImageText(response[0],response[1]));
            	message.acknowledge();
        		ThreadLock.notifyAll();
        	}
        } catch (JMSException e) {
        	System.err.println("Failed reading message from QueueWorkersToManager.");
            e.printStackTrace();
        }
    }
    
    public Long getSize(){
    	return new Long(list.size());
    }
    
    public ArrayList<ImageText> getList(){
    	return new ArrayList<ImageText>(list);
    }
}